// Theme types
export type ThemeType = 'blue' | 'pink';

export interface ThemeColors {
  authBg: string;
  lockBg: string;
  lockText: string;
  lockButton: string;
  mainBg: string;
  sidebarBg: string;
  contentBg: string;
  accent: string;
  accentHover: string;
  cardBg: string;
  cardBorder: string;
  inputBg: string;
  inputBorder: string;
  buttonBg: string;
  buttonText: string;
  buttonHover: string;
}

export interface ThemeContextType {
  theme: ThemeType;
  themes: Record<ThemeType, ThemeColors>;
  currentTheme: ThemeColors;
  setTheme: (theme: ThemeType) => void;
}

// Memo types
export interface Memo {
  id: string;
  title: string;
  content: string;
  createdAt: string;
  updatedAt: string;
  collaborators: string[];
}

export interface MemoContextType {
  memos: Memo[];
  selectedMemo: Memo | null;
  isEditing: boolean;
  editTitle: string;
  editContent: string;
  searchQuery: string;
  setMemos: React.Dispatch<React.SetStateAction<Memo[]>>;
  setSelectedMemo: React.Dispatch<React.SetStateAction<Memo | null>>;
  setIsEditing: React.Dispatch<React.SetStateAction<boolean>>;
  setEditTitle: React.Dispatch<React.SetStateAction<string>>;
  setEditContent: React.Dispatch<React.SetStateAction<string>>;
  setSearchQuery: React.Dispatch<React.SetStateAction<string>>;
  createMemo: () => void;
  deleteMemo: (id: string) => void;
  saveMemo: () => void;
  getFilteredMemos: () => Memo[];
  shareUrl: () => void;
}

// Notification types
export interface Notification {
  message: string;
  type: 'success' | 'error' | 'info';
}

export interface NotificationContextType {
  notification: Notification | null;
  showNotification: (message: string, type?: 'success' | 'error' | 'info') => void;
}