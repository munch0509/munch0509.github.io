import React from 'react';
import { Edit3 } from 'lucide-react';

const EmptyState: React.FC = () => {
  return (
    <div className="flex-1 flex items-center justify-center text-gray-500">
      <div className="text-center">
        <Edit3 className="w-24 h-24 mx-auto mb-6 opacity-20" />
        <h3 className="text-xl font-medium mb-2">メモを選択してください</h3>
        <p>左のリストからメモを選択するか、新しいメモを作成してください</p>
      </div>
    </div>
  );
};

export default EmptyState;