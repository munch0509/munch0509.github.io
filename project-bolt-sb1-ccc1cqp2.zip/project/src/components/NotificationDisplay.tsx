import React from 'react';
import { useNotification } from '../contexts/NotificationContext';

const NotificationDisplay: React.FC = () => {
  const { notification } = useNotification();

  if (!notification) return null;

  const bgColor = 
    notification.type === 'error' ? 'bg-red-500' : 
    notification.type === 'info' ? 'bg-blue-500' : 
    'bg-green-500';

  return (
    <div className={`fixed bottom-6 right-6 px-6 py-3 rounded-xl text-white shadow-lg animate-slideUp z-50 ${bgColor}`}>
      {notification.message}
    </div>
  );
};

export default NotificationDisplay;