import React from 'react';
import { Clock, Users, Trash2, Search } from 'lucide-react';
import { useMemo } from '../contexts/MemoContext';
import { useTheme } from '../contexts/ThemeContext';

const MemoList: React.FC = () => {
  const { 
    selectedMemo, 
    setSelectedMemo, 
    setIsEditing, 
    deleteMemo, 
    getFilteredMemos 
  } = useMemo();
  
  const { theme, currentTheme } = useTheme();
  const filteredMemos = getFilteredMemos();

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-2">
      {filteredMemos.map((memo, index) => (
        <div
          key={memo.id}
          onClick={() => {
            setSelectedMemo(memo);
            setIsEditing(false);
          }}
          className={`p-4 rounded-xl cursor-pointer transition-all duration-200 hover:shadow-md transform hover:scale-102 group ${
            selectedMemo?.id === memo.id 
              ? `bg-gradient-to-r ${currentTheme.cardBg} border-2 ${currentTheme.cardBorder} shadow-md` 
              : 'bg-white border border-gray-100 hover:border-gray-200'
          }`}
          style={{ animationDelay: `${index * 50}ms` }}
        >
          <div className="flex items-start justify-between mb-2">
            <h3 className="font-medium text-gray-800 truncate flex-1 mr-2">
              {memo.title}
            </h3>
            <button
              onClick={(e) => {
                e.stopPropagation();
                deleteMemo(memo.id);
              }}
              className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-red-50 transition-all"
            >
              <Trash2 className="w-4 h-4 text-red-500" />
            </button>
          </div>
          <p className="text-sm text-gray-600 line-clamp-2 mb-2">
            {memo.content.substring(0, 100) || 'メモの内容はありません'}
          </p>
          <div className="flex items-center justify-between text-xs text-gray-500">
            <div className="flex items-center">
              <Clock className="w-3 h-3 mr-1" />
              {new Date(memo.updatedAt).toLocaleDateString('ja-JP')}
            </div>
            <div className="flex items-center">
              <Users className="w-3 h-3 mr-1" />
              {memo.collaborators.length}
            </div>
          </div>
        </div>
      ))}
      
      {filteredMemos.length === 0 && (
        <div className="text-center py-12 text-gray-500">
          <Search className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p>メモが見つかりません</p>
        </div>
      )}
    </div>
  );
};

export default MemoList;