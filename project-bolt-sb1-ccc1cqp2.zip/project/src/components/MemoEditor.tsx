import React from 'react';
import { useMemo } from '../contexts/MemoContext';
import { useTheme } from '../contexts/ThemeContext';

const MemoEditor: React.FC = () => {
  const { 
    selectedMemo, 
    isEditing, 
    editContent, 
    setEditContent 
  } = useMemo();
  
  const { currentTheme } = useTheme();

  if (!selectedMemo) return null;

  return (
    <div className="flex-1 p-6 overflow-y-auto">
      {isEditing ? (
        <textarea
          value={editContent}
          onChange={(e) => setEditContent(e.target.value)}
          placeholder="メモの内容を入力してください..."
          className={`w-full h-full resize-none border-none outline-none text-gray-700 leading-relaxed text-lg ${currentTheme.inputBg} focus:${currentTheme.inputBg} p-4 rounded-lg transition-colors`}
        />
      ) : (
        <div className="prose prose-lg max-w-none">
          <pre className="whitespace-pre-wrap font-sans text-gray-700 leading-relaxed">
            {selectedMemo.content || 'メモの内容はありません。編集ボタンをクリックして内容を追加してください。'}
          </pre>
        </div>
      )}
    </div>
  );
};

export default MemoEditor;