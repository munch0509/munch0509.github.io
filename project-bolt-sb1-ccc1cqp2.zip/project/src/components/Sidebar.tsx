import React from 'react';
import { Search, Plus, Settings, LogOut } from 'lucide-react';
import MemoList from './MemoList';
import { useTheme } from '../contexts/ThemeContext';
import { useMemo } from '../contexts/MemoContext';

interface SidebarProps {
  logout: () => void;
  setShowSettings: (value: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ logout, setShowSettings }) => {
  const { currentTheme } = useTheme();
  const { 
    searchQuery, 
    setSearchQuery, 
    createMemo
  } = useMemo();

  return (
    <div className={`w-80 ${currentTheme.sidebarBg} border-r ${currentTheme.inputBorder} flex flex-col shadow-lg`}>
      {/* Header */}
      <div className={`p-6 border-b ${currentTheme.inputBorder}`}>
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-xl font-bold text-gray-800">SecureNotes</h1>
          <div className="flex space-x-2">
            <button
              onClick={() => setShowSettings(true)}
              className={`p-2 rounded-lg ${currentTheme.buttonBg} ${currentTheme.buttonText} ${currentTheme.buttonHover} transition-colors`}
            >
              <Settings className="w-5 h-5" />
            </button>
            <button
              onClick={logout}
              className={`p-2 rounded-lg ${currentTheme.buttonBg} ${currentTheme.buttonText} ${currentTheme.buttonHover} transition-colors`}
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
        
        {/* Search bar */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="メモを検索..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full pl-10 pr-4 py-2.5 ${currentTheme.inputBg} border ${currentTheme.inputBorder} rounded-xl focus:outline-none focus:ring-2 focus:ring-opacity-50 transition-all`}
          />
        </div>
        
        {/* New memo button */}
        <button
          onClick={createMemo}
          className={`w-full bg-gradient-to-r ${currentTheme.accent} text-white py-3 px-4 rounded-xl font-medium hover:bg-gradient-to-r hover:${currentTheme.accentHover} transition-all duration-200 transform hover:scale-105 shadow-lg flex items-center justify-center`}
        >
          <Plus className="w-5 h-5 mr-2" />
          新しいメモ
        </button>
      </div>

      {/* Memo list */}
      <MemoList />
    </div>
  );
};

export default Sidebar;