import React from 'react';
import Sidebar from './Sidebar';
import MemoContent from './MemoContent';
import { useTheme } from '../contexts/ThemeContext';

interface MemoAppProps {
  logout: () => void;
  setShowSettings: (value: boolean) => void;
}

const MemoApp: React.FC<MemoAppProps> = ({ logout, setShowSettings }) => {
  const { currentTheme } = useTheme();

  return (
    <div className={`h-screen ${currentTheme.mainBg} flex overflow-hidden`}>
      <Sidebar logout={logout} setShowSettings={setShowSettings} />
      <MemoContent />
    </div>
  );
};

export default MemoApp;