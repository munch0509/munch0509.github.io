import React, { useState } from 'react';
import { Palette } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { ThemeType } from '../types';

interface SettingsModalProps {
  setShowSettings: (value: boolean) => void;
  handlePasswordChange: (newPassword: string) => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ 
  setShowSettings, 
  handlePasswordChange 
}) => {
  const { theme, setTheme, currentTheme } = useTheme();
  
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  const handleThemeChange = (newTheme: ThemeType) => {
    setTheme(newTheme);
  };
  
  const handleSubmit = () => {
    if (newPassword === confirmPassword && newPassword.length >= 4) {
      handlePasswordChange(newPassword);
      setNewPassword('');
      setConfirmPassword('');
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className={`${currentTheme.contentBg} rounded-2xl p-6 w-full max-w-md shadow-2xl animate-fadeIn`}>
        <h3 className="text-xl font-bold text-gray-800 mb-6">設定</h3>
        
        <div className="space-y-6">
          {/* Theme selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              <Palette className="w-4 h-4 inline mr-2" />
              テーマカラー
            </label>
            <div className="flex space-x-3">
              <button
                onClick={() => handleThemeChange('blue')}
                className={`flex-1 p-4 rounded-xl border-2 transition-all ${
                  theme === 'blue' 
                    ? `${currentTheme.cardBorder} ${currentTheme.inputBg}` 
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="w-full h-8 bg-gradient-to-r from-blue-900 to-black rounded-lg mb-2"></div>
                <div className="text-sm font-medium">ディープブルー</div>
              </button>
              <button
                onClick={() => handleThemeChange('pink')}
                className={`flex-1 p-4 rounded-xl border-2 transition-all ${
                  theme === 'pink' 
                    ? `${currentTheme.cardBorder} ${currentTheme.inputBg}` 
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="w-full h-8 bg-gradient-to-r from-pink-100 to-white rounded-lg mb-2"></div>
                <div className="text-sm font-medium">ソフトピンク</div>
              </button>
            </div>
          </div>
          
          {/* Password change */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              新しいパスワード
            </label>
            <input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className={`w-full px-4 py-2 border ${currentTheme.inputBorder} ${currentTheme.inputBg} rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50`}
              placeholder="4桁以上"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              パスワード確認
            </label>
            <input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className={`w-full px-4 py-2 border ${currentTheme.inputBorder} ${currentTheme.inputBg} rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50`}
              placeholder="もう一度入力"
            />
          </div>
        </div>
        
        <div className="flex space-x-3 mt-6">
          <button
            onClick={() => setShowSettings(false)}
            className={`flex-1 px-4 py-2 border ${currentTheme.inputBorder} ${currentTheme.buttonText} rounded-lg ${currentTheme.buttonHover} transition-colors`}
          >
            キャンセル
          </button>
          <button
            onClick={handleSubmit}
            className={`flex-1 px-4 py-2 bg-gradient-to-r ${currentTheme.accent} text-white rounded-lg hover:bg-gradient-to-r hover:${currentTheme.accentHover} transition-colors`}
          >
            変更
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;