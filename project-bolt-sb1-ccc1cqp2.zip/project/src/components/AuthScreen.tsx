import React from 'react';
import { useTheme } from '../contexts/ThemeContext';
import { Lock, Unlock, Eye, EyeOff } from 'lucide-react';

interface AuthScreenProps {
  password: string;
  inputPassword: string;
  showPassword: boolean;
  authError: string;
  animationClass: string;
  setInputPassword: (value: string) => void;
  setShowPassword: (value: boolean) => void;
  handleAuth: () => void;
}

const AuthScreen: React.FC<AuthScreenProps> = ({
  inputPassword,
  showPassword,
  authError,
  animationClass,
  setInputPassword,
  setShowPassword,
  handleAuth
}) => {
  const { currentTheme } = useTheme();

  return (
    <div className={`min-h-screen ${currentTheme.authBg} flex items-center justify-center p-4 relative overflow-hidden`}>
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 rounded-full bg-white/5 blur-3xl"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 rounded-full bg-white/5 blur-3xl"></div>
      </div>
      
      <div className={`${currentTheme.lockBg} rounded-3xl p-8 w-full max-w-sm shadow-2xl ${animationClass} relative z-10`}>
        {/* Time display (iPhone style) */}
        <div className={`text-center mb-8 ${currentTheme.lockText}`}>
          <div className="text-4xl font-thin mb-2">
            {new Date().toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit' })}
          </div>
          <div className="text-lg font-light opacity-80">
            {new Date().toLocaleDateString('ja-JP', { 
              month: 'long', 
              day: 'numeric',
              weekday: 'long'
            })}
          </div>
        </div>
        
        {/* Lock icon */}
        <div className="text-center mb-8">
          <div className={`w-20 h-20 ${currentTheme.lockButton} rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg transition-all duration-300`}>
            <Lock className={`w-10 h-10 ${currentTheme.lockText}`} />
          </div>
          <div className={`text-lg font-medium ${currentTheme.lockText} opacity-90`}>
            SecureNotes
          </div>
        </div>
        
        {/* Password input */}
        <div className="space-y-4">
          <div className="relative">
            <input
              type={showPassword ? "text" : "password"}
              value={inputPassword}
              onChange={(e) => setInputPassword(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleAuth()}
              placeholder="パスワードを入力"
              className={`w-full px-6 py-4 ${currentTheme.lockBg} ${currentTheme.lockText} rounded-2xl focus:outline-none focus:ring-2 focus:ring-white/30 transition-all placeholder-gray-400 text-center text-lg font-medium tracking-widest`}
            />
            <button
              onClick={() => setShowPassword(!showPassword)}
              className={`absolute right-4 top-4 ${currentTheme.lockText} opacity-60 hover:opacity-100 transition-opacity`}
            >
              {showPassword ? <EyeOff className="w-6 h-6" /> : <Eye className="w-6 h-6" />}
            </button>
          </div>
          
          {authError && (
            <div className="text-red-400 text-sm text-center bg-red-500/10 p-3 rounded-xl border border-red-400/20">
              {authError}
            </div>
          )}
          
          <button
            onClick={handleAuth}
            className={`w-full ${currentTheme.lockButton} ${currentTheme.lockText} py-4 rounded-2xl font-medium transition-all duration-200 transform hover:scale-105 shadow-lg flex items-center justify-center text-lg`}
          >
            <Unlock className="w-6 h-6 mr-2" />
            ロック解除
          </button>
        </div>
      </div>
    </div>
  );
};

export default AuthScreen;