import React from 'react';
import { useMemo } from '../contexts/MemoContext';
import { useTheme } from '../contexts/ThemeContext';
import MemoHeader from './MemoHeader';
import MemoEditor from './MemoEditor';
import EmptyState from './EmptyState';

const MemoContent: React.FC = () => {
  const { selectedMemo } = useMemo();
  const { currentTheme } = useTheme();

  return (
    <div className={`flex-1 flex flex-col ${currentTheme.contentBg}`}>
      {selectedMemo ? (
        <>
          <MemoHeader />
          <MemoEditor />
        </>
      ) : (
        <EmptyState />
      )}
    </div>
  );
};

export default MemoContent;