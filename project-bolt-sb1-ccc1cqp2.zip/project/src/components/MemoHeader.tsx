import React from 'react';
import { Share2, Edit3, Save, Clock, Users } from 'lucide-react';
import { useMemo } from '../contexts/MemoContext';
import { useTheme } from '../contexts/ThemeContext';

const MemoHeader: React.FC = () => {
  const { 
    selectedMemo, 
    isEditing, 
    editTitle, 
    setEditTitle, 
    setIsEditing, 
    saveMemo, 
    shareUrl 
  } = useMemo();
  
  const { currentTheme } = useTheme();

  if (!selectedMemo) return null;

  return (
    <div className={`p-6 border-b ${currentTheme.inputBorder} ${currentTheme.contentBg}`}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex-1">
          {isEditing ? (
            <input
              type="text"
              value={editTitle}
              onChange={(e) => setEditTitle(e.target.value)}
              className={`text-2xl font-bold text-gray-800 ${currentTheme.inputBg} border-none outline-none w-full p-2 rounded-lg transition-colors`}
              placeholder="メモのタイトル"
            />
          ) : (
            <h2 className="text-2xl font-bold text-gray-800">{selectedMemo.title}</h2>
          )}
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={shareUrl}
            className={`p-3 rounded-xl ${currentTheme.buttonBg} ${currentTheme.buttonText} ${currentTheme.buttonHover} transition-colors shadow-sm`}
          >
            <Share2 className="w-5 h-5" />
          </button>
          <button
            onClick={() => {
              if (isEditing) {
                saveMemo();
                setIsEditing(false);
              } else {
                setIsEditing(true);
              }
            }}
            className={`p-3 rounded-xl transition-colors shadow-sm ${
              isEditing 
                ? `bg-gradient-to-r ${currentTheme.accent} text-white hover:bg-gradient-to-r hover:${currentTheme.accentHover}` 
                : `${currentTheme.buttonBg} ${currentTheme.buttonText} ${currentTheme.buttonHover}`
            }`}
          >
            {isEditing ? <Save className="w-5 h-5" /> : <Edit3 className="w-5 h-5" />}
          </button>
        </div>
      </div>
      
      <div className="flex items-center text-sm text-gray-500 space-x-4">
        <div className="flex items-center">
          <Clock className="w-4 h-4 mr-1" />
          更新: {new Date(selectedMemo.updatedAt).toLocaleString('ja-JP')}
        </div>
        <div className="flex items-center">
          <Users className="w-4 h-4 mr-1" />
          共同編集者: {selectedMemo.collaborators.join(', ')}
        </div>
      </div>
    </div>
  );
};

export default MemoHeader;