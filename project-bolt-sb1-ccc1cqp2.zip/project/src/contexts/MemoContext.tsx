import React, { createContext, useState, useContext, useRef, useEffect, ReactNode } from 'react';
import { Memo, MemoContextType } from '../types';
import { useNotification } from './NotificationContext';

const MemoContext = createContext<MemoContextType | undefined>(undefined);

export const MemoProvider = ({ children }: { children: ReactNode }) => {
  const { showNotification } = useNotification();
  
  // Memo states
  const [memos, setMemos] = useState<Memo[]>([
    {
      id: '1',
      title: 'ウェルカムメモ',
      content: 'このアプリへようこそ！\n\n• メモの作成・編集・削除が可能です\n• リアルタイムで他のユーザーと共有できます\n• URLを使って簡単に共有できます\n\n左上の「+」ボタンで新しいメモを作成しましょう。',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      collaborators: ['あなた']
    }
  ]);
  const [selectedMemo, setSelectedMemo] = useState<Memo | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editContent, setEditContent] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  // Auto-save timer
  const autoSaveTimer = useRef<NodeJS.Timeout | null>(null);

  // Create a new memo
  const createMemo = () => {
    const newMemo: Memo = {
      id: Date.now().toString(),
      title: '新しいメモ',
      content: '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      collaborators: ['あなた']
    };
    setMemos(prev => [newMemo, ...prev]);
    setSelectedMemo(newMemo);
    setIsEditing(true);
    setEditTitle(newMemo.title);
    setEditContent(newMemo.content);
  };

  // Delete a memo
  const deleteMemo = (id: string) => {
    if (window.confirm('このメモを削除しますか？')) {
      setMemos(prev => prev.filter(memo => memo.id !== id));
      if (selectedMemo?.id === id) {
        setSelectedMemo(null);
        setIsEditing(false);
      }
      showNotification('メモを削除しました');
    }
  };

  // Save a memo
  const saveMemo = () => {
    if (selectedMemo && isEditing) {
      const updatedMemo: Memo = {
        ...selectedMemo,
        title: editTitle,
        content: editContent,
        updatedAt: new Date().toISOString()
      };
      setMemos(prev => prev.map(memo => 
        memo.id === selectedMemo.id ? updatedMemo : memo
      ));
      setSelectedMemo(updatedMemo);
      showNotification('自動保存しました', 'info');
    }
  };

  // Get filtered memos based on search query
  const getFilteredMemos = () => {
    return memos.filter(memo =>
      memo.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      memo.content.toLowerCase().includes(searchQuery.toLowerCase())
    );
  };

  // Share memo URL
  const shareUrl = () => {
    if (selectedMemo) {
      const shareUrl = `${window.location.origin}?memo=${selectedMemo.id}`;
      navigator.clipboard.writeText(shareUrl);
      showNotification('共有URLをコピーしました！');
    }
  };

  // Auto-save when editing
  useEffect(() => {
    if (isEditing && selectedMemo && (editTitle !== selectedMemo.title || editContent !== selectedMemo.content)) {
      if (autoSaveTimer.current) {
        clearTimeout(autoSaveTimer.current);
      }
      autoSaveTimer.current = setTimeout(saveMemo, 2000);
    }
    return () => {
      if (autoSaveTimer.current) {
        clearTimeout(autoSaveTimer.current);
      }
    };
  }, [editTitle, editContent, isEditing, selectedMemo]);

  return (
    <MemoContext.Provider value={{
      memos,
      selectedMemo,
      isEditing,
      editTitle,
      editContent,
      searchQuery,
      setMemos,
      setSelectedMemo,
      setIsEditing,
      setEditTitle,
      setEditContent,
      setSearchQuery,
      createMemo,
      deleteMemo,
      saveMemo,
      getFilteredMemos,
      shareUrl
    }}>
      {children}
    </MemoContext.Provider>
  );
};

export const useMemo = (): MemoContextType => {
  const context = useContext(MemoContext);
  if (context === undefined) {
    throw new Error('useMemo must be used within a MemoProvider');
  }
  return context;
};