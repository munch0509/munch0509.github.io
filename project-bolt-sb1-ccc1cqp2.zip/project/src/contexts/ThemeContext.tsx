import React, { createContext, useState, useContext, ReactNode } from 'react';
import { ThemeType, ThemeColors, ThemeContextType } from '../types';

const themes: Record<ThemeType, ThemeColors> = {
  blue: {
    authBg: 'bg-gradient-to-br from-blue-900 via-blue-800 to-black',
    lockBg: 'bg-white/10 backdrop-blur-md border border-white/20',
    lockText: 'text-white',
    lockButton: 'bg-white/20 hover:bg-white/30 backdrop-blur-md border border-white/30',
    mainBg: 'bg-gray-50',
    sidebarBg: 'bg-white',
    contentBg: 'bg-white',
    accent: 'from-blue-500 to-indigo-600',
    accentHover: 'from-blue-600 to-indigo-700',
    cardBg: 'from-indigo-50 to-purple-50',
    cardBorder: 'border-indigo-200',
    inputBg: 'bg-blue-50/50',
    inputBorder: 'border-blue-200',
    buttonBg: 'bg-blue-50',
    buttonText: 'text-blue-600',
    buttonHover: 'hover:bg-blue-100'
  },
  pink: {
    authBg: 'bg-gradient-to-br from-pink-100 via-rose-50 to-white',
    lockBg: 'bg-white/60 backdrop-blur-md border border-pink-200/50',
    lockText: 'text-gray-800',
    lockButton: 'bg-pink-100/80 hover:bg-pink-200/80 backdrop-blur-md border border-pink-200/50',
    mainBg: 'bg-pink-50/30',
    sidebarBg: 'bg-white',
    contentBg: 'bg-white',
    accent: 'from-pink-400 to-rose-500',
    accentHover: 'from-pink-500 to-rose-600',
    cardBg: 'from-pink-50 to-rose-50',
    cardBorder: 'border-pink-200',
    inputBg: 'bg-pink-50/50',
    inputBorder: 'border-pink-200',
    buttonBg: 'bg-pink-50',
    buttonText: 'text-pink-600',
    buttonHover: 'hover:bg-pink-100'
  }
};

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider = ({ children }: { children: ReactNode }) => {
  const [theme, setTheme] = useState<ThemeType>('blue');
  
  const currentTheme = themes[theme];

  return (
    <ThemeContext.Provider value={{ theme, themes, currentTheme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};