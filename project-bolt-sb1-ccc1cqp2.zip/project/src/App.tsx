import React from 'react';
import { ThemeProvider } from './contexts/ThemeContext';
import { MemoProvider } from './contexts/MemoContext';
import { NotificationProvider } from './contexts/NotificationContext';
import SecureNotesApp from './components/SecureNotesApp';

function App() {
  return (
    <ThemeProvider>
      <NotificationProvider>
        <MemoProvider>
          <SecureNotesApp />
        </MemoProvider>
      </NotificationProvider>
    </ThemeProvider>
  );
}

export default App;