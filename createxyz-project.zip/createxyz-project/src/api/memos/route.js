async function handler({ id, title, content }, method) {
  const session = getSession();

  if (!session?.user?.id) {
    return { status: 401, error: "Unauthorized" };
  }

  try {
    switch (method) {
      case "GET": {
        const memos = await sql`
          SELECT id, title, content, images, created_at, updated_at 
          FROM memos 
          WHERE user_id = ${session.user.id} 
          ORDER BY updated_at DESC
        `;
        return { status: 200, data: memos };
      }

      case "POST": {
        if (!title) {
          return { status: 400, error: "Title is required" };
        }

        // Extract image URLs from content
        const imageUrls = (content.match(/!\[.*?\]\((.*?)\)/g) || []).map(
          (img) => img.match(/!\[.*?\]\((.*?)\)/)[1]
        );

        const [memo] = await sql`
          INSERT INTO memos (title, content, images, user_id) 
          VALUES (${title}, ${content}, ${imageUrls}, ${session.user.id}) 
          RETURNING id, title, content, images, created_at, updated_at
        `;
        return { status: 201, data: memo };
      }

      case "PUT": {
        if (!id) {
          return { status: 400, error: "ID is required" };
        }
        if (!title) {
          return { status: 400, error: "Title is required" };
        }

        // Extract image URLs from content
        const imageUrls = (content.match(/!\[.*?\]\((.*?)\)/g) || []).map(
          (img) => img.match(/!\[.*?\]\((.*?)\)/)[1]
        );

        const [memo] = await sql`
          UPDATE memos 
          SET title = ${title}, 
              content = ${content},
              images = ${imageUrls},
              updated_at = CURRENT_TIMESTAMP 
          WHERE id = ${id} 
          AND user_id = ${session.user.id} 
          RETURNING id, title, content, images, created_at, updated_at
        `;

        if (!memo) {
          return { status: 404, error: "Memo not found" };
        }
        return { status: 200, data: memo };
      }

      case "DELETE": {
        if (!id) {
          return { status: 400, error: "ID is required" };
        }

        const [memo] = await sql`
          DELETE FROM memos 
          WHERE id = ${id} 
          AND user_id = ${session.user.id} 
          RETURNING id
        `;

        if (!memo) {
          return { status: 404, error: "Memo not found" };
        }
        return { status: 200 };
      }

      default:
        return { status: 405, error: "Method not allowed" };
    }
  } catch (error) {
    console.error("Error in memos handler:", error);
    return { status: 500, error: "Internal server error" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}