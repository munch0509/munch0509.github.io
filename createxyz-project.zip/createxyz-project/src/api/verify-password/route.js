async function handler({ password }) {
  const session = getSession();

  if (!session?.user?.id) {
    return { status: 401, error: "Unauthorized" };
  }

  try {
    const [userSettings] = await sql`
      SELECT password 
      FROM user_settings 
      WHERE user_id = ${session.user.id}
    `;

    const storedPassword = userSettings?.password || "0000";

    if (password === storedPassword) {
      return { status: 200 };
    } else {
      return { status: 401, error: "Invalid password" };
    }
  } catch (error) {
    return { status: 500, error: "Internal server error" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}