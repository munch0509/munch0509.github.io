async function handler({ password, theme }) {
  const session = getSession();

  if (!session?.user?.id) {
    return { status: 401, error: "Unauthorized" };
  }

  try {
    if (!password && !theme) {
      return { status: 400, error: "No updates provided" };
    }

    let setClause = [];
    let values = [];
    let paramCount = 1;

    if (password) {
      setClause.push(`password = $${paramCount}`);
      values.push(password);
      paramCount++;
    }

    if (theme) {
      if (!["pink", "brown"].includes(theme)) {
        return { status: 400, error: "Invalid theme value" };
      }
      setClause.push(`theme = $${paramCount}`);
      values.push(theme);
      paramCount++;
    }

    const query = `
      INSERT INTO user_settings (user_id, ${password ? "password" : ""} ${
      theme ? (password ? ", theme" : "theme") : ""
    })
      VALUES ($${paramCount}${password ? `, $1` : ""}${
      theme ? (password ? `, $2` : `, $1`) : ""
    })
      ON CONFLICT (user_id) 
      DO UPDATE SET ${setClause.join(", ")}
      RETURNING *
    `;

    values.push(session.user.id);

    const [updatedSettings] = await sql(query, values);

    return {
      status: 200,
      data: {
        theme: updatedSettings.theme,
        password: updatedSettings.password,
      },
    };
  } catch (error) {
    console.error("Error updating settings:", error);
    return { status: 500, error: "Internal server error" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}